 </div><!-- /.blog-main -->
      </div><!-- /.row -->

    </div><!-- /.container -->

    <div class="blog-footer">
      <p>PHPLoversBlog &copy; 2014</p>
      <p>
        <a href="#">Back to top</a>
      </p>
    </div>


    <!-- Bootstrap core JavaScript
    ================================================== -->
    <!-- Placed at the end of the document so the pages load faster -->
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/1.11.0/jquery.min.js"></script>
    <script src="../js/bootstrap.js"></script>
  </body>
</html>